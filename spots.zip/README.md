# Project 3: Spots

Spots is an image sharing webpage.

#description
This webpage is the third project in the Software Engineering program at TripleTen.
The exercise introduced figma as a design sharing tool, techniques in building a screen-size adaptable webpage, and utilized skills learned in previous projects.

#tech-stack

- Figma
- github
- html
- css
- responsive design
- JavaScript

#Deployment

This project is deployed to GitHub pages
deployment link- https://miagi-jade.github.io/se_project_spots/

Here is a link to a short video report on the project:
https://drive.google.com/file/d/1Bhxmik6NYc6xrNWuUj0e64L7vXMLbw3w/view?usp=sharing
